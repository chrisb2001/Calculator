import tkinter as tk
from tkinter import messagebox, simpledialog
from calculator import Calculator
from history import HistoryWindow
from whatsapp import send_whatsapp_message  

class WindowInputDevice:
    
    # Define theme colors
    BACKGROUND_COLOR = "#f0f0f0"
    BUTTON_COLOR = "#d9d9d9"
    BUTTON_TEXT_COLOR = "black"

    def __init__(self, calculator, title):
        self.calculator = calculator
        self.root = tk.Tk()
        self.root.title(title)
        self.root.geometry("400x400")
        self.root.grid_columnconfigure(0, weight=1)  # Allow column 0 to expand
        self.root.grid_rowconfigure(0, weight=1)     # Allow row 0 to expand
        self.root.configure(bg=self.BACKGROUND_COLOR)  # Set background color

        # Entry widget
        self.entry = tk.Entry(self.root, justify="right", font=("Helvetica", 20), width=35, bg="white")
        self.entry.grid(row=0, column=0, columnspan=7, sticky="ew")  # Make the entry expand horizontally

        button_layout = [
            ('7', 1, 0), ('8', 1, 1), ('9', 1, 2), ('/', 1, 3),
            ('4', 2, 0), ('5', 2, 1), ('6', 2, 2), ('*', 2, 3),
            ('1', 3, 0), ('2', 3, 1), ('3', 3, 2), ('-', 3, 3),
            ('0', 4, 1), ('C', 4, 0), ('=', 4, 5), ('+', 4, 3),
            ('%', 2, 4),('//', 1, 4),('.', 4, 2),('DEL', 3, 5),
            ('(', 1, 5),(')', 2, 5),('sin', 3, 4),('sqrt', 4, 4)  
        ]

        button_width = 8
        button_height = 4

        self.buttons = []

        for text, row, col in button_layout:
            button = tk.Button(self.root, text=text, padx=10, pady=10, font=("Helvetica", 12),
                               command=lambda t=text: self.handle_button_press(t),
                               bg=self.BUTTON_COLOR, fg=self.BUTTON_TEXT_COLOR)
            button.grid(row=row, column=col, sticky="nsew")  # Make the buttons expand in all directions
            self.buttons.append(button)

            # Configure button width and height to make them equal-sized
            button.grid_configure(ipadx=10, ipady=10)

        self.root.bind('<KeyPress>', self.on_key_press)
        
        # Menu for theme and color settings
        menu = tk.Menu(self.root)
        self.root.config(menu=menu)
        
        theme_menu = tk.Menu(menu, tearoff=0)
        menu.add_cascade(label="Themes", menu=theme_menu)
        theme_menu.add_command(label="Default Theme", command=self.set_default_theme)
        theme_menu.add_command(label="Dark Theme", command=self.set_dark_theme)
        theme_menu.add_command(label="Israel Theme", command=self.set_israel_theme)
        theme_menu.add_command(label="Console Theme", command=self.set_console_theme)

        color_menu = tk.Menu(menu, tearoff=0)
        menu.add_cascade(label="Color", menu=color_menu)
        color_menu.add_command(label="Change Entry Theme", command=self.change_entry_theme_color)
        
        add_on_menu = tk.Menu(menu, tearoff=0)
        menu.add_cascade(label="Add on", menu=add_on_menu)
        add_on_menu.add_checkbutton(label="Enable History", command=self.toggle_history)
        add_on_menu.add_command(label="Show History", command=self.show_history)
        add_on_menu.add_checkbutton(label="Support", command=self.support)

        self.history_enabled = False  # History feature is off by default
        self.history_list = []  # List to store history of calculator operations
        
        #add_on_menu.add_checkbutton(label="Support", command=self.support)
        
        self.run()

    def handle_button_press(self, button_text):
        if button_text == 'C':
            self.entry.delete(0, tk.END)
        elif button_text == 'DEL':
            current_text = self.entry.get()
            self.entry.delete(len(current_text) - 1, tk.END)
        elif button_text == '=':
            self.calculate_result()
        elif button_text == 'sin':
            self.entry.insert(tk.END, 'sin(')
        elif button_text == 'sqrt':  
            self.entry.insert(tk.END, 'sqrt(')
        else:
            self.entry.insert(tk.END, button_text)

    def on_key_press(self, event):
        key = event.char
        if key.isdigit() or key in ['+', '-', '*', '/', '%', '.']:
            self.entry.insert(tk.END, key)
        elif event.keysym == 'Return':
            self.calculate_result()
        elif event.keysym == 'BackSpace':
            current_text = self.entry.get()
            self.entry.delete(len(current_text) - 1, tk.END)

    def calculate_result(self):
        expression = self.entry.get()
        expression = expression.replace('sin(', 'self.calculator.sin(')  # Modify sin operation
        expression = expression.replace('sqrt(', 'self.calculator.square_root(')  # Modify sqrt operation
        try:
            result = eval(expression)
            self.entry.delete(0, tk.END)
            self.entry.insert(tk.END, str(result))
            if self.history_enabled:
                self.history_list.append(expression + " = " + str(result))
        except Exception as e:
            messagebox.showerror("Error", str(e))

    def toggle_history(self):
        self.history_enabled = not self.history_enabled

    def show_history(self):
        if self.history_enabled:
            HistoryWindow(self.history_list)
        else:
            messagebox.showinfo("History", "History feature is not enabled. Enable it from the History menu.")
            
    def support(self):
        messagebox.showinfo("Support Requested", "Support has been requested. We will contact you shortly.")
        send_whatsapp_message()

    def set_default_theme(self):
        self.root.configure(bg='#f0f0f0')
        self.entry.configure(bg='white', fg='black')
        for button in self.buttons:
            button.configure(bg='#d9d9d9', fg='black')

    def set_dark_theme(self):
        self.root.configure(bg='black')
        self.entry.configure(bg='black', fg='white')
        for button in self.buttons:
            button.configure(bg='black', fg='white')

    def set_israel_theme(self):
        self.root.configure(bg='#0038b8')
        self.entry.configure(bg='#0038b8', fg='white')
        for button in self.buttons:
            button.configure(bg='#0038b8', fg='white')

    def set_console_theme(self):
        self.root.configure(bg='black')
        self.entry.configure(bg='black', fg='green')
        for button in self.buttons:
            button.configure(bg='black', fg='green')

    def change_entry_theme_color(self):
        color_bg = simpledialog.askstring("Change Entry Background", "Enter background color (e.g., red, #FF0000):")
        color_fg = simpledialog.askstring("Change Entry Foreground", "Enter foreground color (e.g., black, #000000):")
    
        if color_bg and color_fg:
            self.entry.configure(bg=color_bg, fg=color_fg)
            for button in self.buttons:
                button.configure(bg=color_bg, fg=color_fg)

    def run(self):
        self.root.mainloop()
