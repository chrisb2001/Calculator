import tkinter as tk

class HistoryWindow:
    def __init__(self, history_list):
        self.history_list = history_list
        self.root = tk.Toplevel()
        self.root.geometry("250x400")
        self.root.title("History")
        self.text = tk.Text(self.root)
        self.text.pack(fill="both", expand=True)

        self.update_history()

    def update_history(self):
        self.text.delete("1.0", "end")
        for item in self.history_list:
            self.text.insert("end", f"{item}\n")
        self.text.config(state="disabled")     
