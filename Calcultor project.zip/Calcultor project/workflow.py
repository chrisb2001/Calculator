from windowdeviceinput import WindowInputDevice
from calculator import Calculator

def main():
    calculator = Calculator()
    window_input_device = WindowInputDevice(calculator, "Calculator")

if __name__ == "__main__":
    main()


