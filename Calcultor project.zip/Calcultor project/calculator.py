import math

class Calculator:
    def __init__(self):
        self.result = 0

    def add(self, a, b):
        return a + b

    def subtract(self, a, b):
        return a - b

    def multiply(self, a, b):
        return a * b

    def divide(self, a, b):
        if b == 0:
            raise ValueError("Cannot divide by zero")
        return a / b

    def floor_divide(self, a, b):
        if b == 0:
            raise ValueError("Cannot divide by zero")
        return a // b

    def mod(self, a, b):
        if b == 0:
            raise ValueError("Cannot divide by zero")
        return a % b

    def square_root(self, a):
        if a < 0:
            raise ValueError("Cannot take square root of a negative number")
        return math.sqrt(a)

    def sin(self, a):
        return math.sin(a)

    def calculate(self, input_object):
        x = input_object.numbers[0]
        y = input_object.numbers[1]

        match input_object.operation:
            case "+": self.result = self.add(x, y)
            case "-": self.result = self.subtract(x, y)
            case "*": self.result = self.multiply(x, y)
            case "/": self.result = self.divide(x, y)
            case "//": self.result = self.floor_divide(x, y)
            case "%": self.result = self.mod(x, y)
            case "square_root": self.result = self.square_root(x)
            case "sin": self.result = self.sin(x)
            case _: self.result = "Error. Can't perform operation"
