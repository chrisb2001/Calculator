import pywhatkit
from datetime import datetime, timedelta
import pytz

def send_whatsapp_message():
    phone_number = "#"

    # Get current time with the PC's time zone
    pc_time_zone = pytz.timezone(pytz.country_timezones['IL'][0])  # Israel time zone
    current_time = datetime.now(pc_time_zone)

    # Add a longer wait time (e.g., 3 minutes) to the current time
    wait_time = timedelta(minutes=3)
    call_time = current_time + wait_time

    # Define the message you want to send
    message = f"I need support with the calculator application. Sent at: {current_time.strftime('%Y-%m-%d %H:%M:%S')}"

    # Send the message
    pywhatkit.sendwhatmsg(phone_number, message, call_time.hour, call_time.minute)


